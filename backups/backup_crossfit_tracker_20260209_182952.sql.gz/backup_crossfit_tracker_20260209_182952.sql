--
-- PostgreSQL database dump
--

\restrict hI3ObjuejUevBicD1dMx02iKLDXlPQeLPcEiw7DhChVFQ0RykijL4jw4WvO47hA

-- Dumped from database version 15.15 (Debian 15.15-1.pgdg13+1)
-- Dumped by pg_dump version 15.15 (Debian 15.15-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.user_skills DROP CONSTRAINT IF EXISTS user_skills_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_skills DROP CONSTRAINT IF EXISTS user_skills_skill_id_fkey;
ALTER TABLE IF EXISTS ONLY public.lifts DROP CONSTRAINT IF EXISTS lifts_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.lifts DROP CONSTRAINT IF EXISTS lifts_exercise_id_fkey;
ALTER TABLE IF EXISTS ONLY public.benchmark_results DROP CONSTRAINT IF EXISTS benchmark_results_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.benchmark_results DROP CONSTRAINT IF EXISTS benchmark_results_benchmark_id_fkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_username_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.user_skills DROP CONSTRAINT IF EXISTS user_skills_pkey;
ALTER TABLE IF EXISTS ONLY public.user_skills DROP CONSTRAINT IF EXISTS uq_user_skill;
ALTER TABLE IF EXISTS ONLY public.skills DROP CONSTRAINT IF EXISTS skills_pkey;
ALTER TABLE IF EXISTS ONLY public.skills DROP CONSTRAINT IF EXISTS skills_name_key;
ALTER TABLE IF EXISTS ONLY public.lifts DROP CONSTRAINT IF EXISTS lifts_pkey;
ALTER TABLE IF EXISTS ONLY public.exercises DROP CONSTRAINT IF EXISTS exercises_pkey;
ALTER TABLE IF EXISTS ONLY public.exercises DROP CONSTRAINT IF EXISTS exercises_name_key;
ALTER TABLE IF EXISTS ONLY public.benchmarks DROP CONSTRAINT IF EXISTS benchmarks_pkey;
ALTER TABLE IF EXISTS ONLY public.benchmarks DROP CONSTRAINT IF EXISTS benchmarks_name_key;
ALTER TABLE IF EXISTS ONLY public.benchmark_results DROP CONSTRAINT IF EXISTS benchmark_results_pkey;
ALTER TABLE IF EXISTS ONLY public.alembic_version DROP CONSTRAINT IF EXISTS alembic_version_pkc;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_skills ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.skills ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.lifts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.exercises ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.benchmarks ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.benchmark_results ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.user_skills_id_seq;
DROP TABLE IF EXISTS public.user_skills;
DROP SEQUENCE IF EXISTS public.skills_id_seq;
DROP TABLE IF EXISTS public.skills;
DROP SEQUENCE IF EXISTS public.lifts_id_seq;
DROP TABLE IF EXISTS public.lifts;
DROP SEQUENCE IF EXISTS public.exercises_id_seq;
DROP TABLE IF EXISTS public.exercises;
DROP SEQUENCE IF EXISTS public.benchmarks_id_seq;
DROP TABLE IF EXISTS public.benchmarks;
DROP SEQUENCE IF EXISTS public.benchmark_results_id_seq;
DROP TABLE IF EXISTS public.benchmark_results;
DROP TABLE IF EXISTS public.alembic_version;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: benchmark_results; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.benchmark_results (
    id integer NOT NULL,
    user_id integer NOT NULL,
    benchmark_id integer NOT NULL,
    time_seconds integer,
    rounds integer,
    reps integer,
    rx boolean NOT NULL,
    date date NOT NULL,
    notes text,
    created_at timestamp without time zone
);


--
-- Name: benchmark_results_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.benchmark_results_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: benchmark_results_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.benchmark_results_id_seq OWNED BY public.benchmark_results.id;


--
-- Name: benchmarks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.benchmarks (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    benchmark_type character varying(20) NOT NULL,
    is_default boolean
);


--
-- Name: benchmarks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.benchmarks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: benchmarks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.benchmarks_id_seq OWNED BY public.benchmarks.id;


--
-- Name: exercises; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.exercises (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    is_default boolean
);


--
-- Name: exercises_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.exercises_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: exercises_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.exercises_id_seq OWNED BY public.exercises.id;


--
-- Name: lifts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lifts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    exercise_id integer NOT NULL,
    weight double precision NOT NULL,
    reps_type integer NOT NULL,
    date date NOT NULL,
    created_at timestamp without time zone
);


--
-- Name: lifts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.lifts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: lifts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.lifts_id_seq OWNED BY public.lifts.id;


--
-- Name: skills; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skills (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    is_default boolean
);


--
-- Name: skills_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.skills_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: skills_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.skills_id_seq OWNED BY public.skills.id;


--
-- Name: user_skills; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_skills (
    id integer NOT NULL,
    user_id integer NOT NULL,
    skill_id integer NOT NULL,
    unlocked_date date NOT NULL
);


--
-- Name: user_skills_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_skills_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_skills_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_skills_id_seq OWNED BY public.user_skills.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(80) NOT NULL,
    email character varying(120) NOT NULL,
    password_hash character varying(128) NOT NULL,
    created_at timestamp without time zone,
    profile_photo character varying(200),
    dark_mode boolean DEFAULT false NOT NULL
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: benchmark_results id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.benchmark_results ALTER COLUMN id SET DEFAULT nextval('public.benchmark_results_id_seq'::regclass);


--
-- Name: benchmarks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.benchmarks ALTER COLUMN id SET DEFAULT nextval('public.benchmarks_id_seq'::regclass);


--
-- Name: exercises id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exercises ALTER COLUMN id SET DEFAULT nextval('public.exercises_id_seq'::regclass);


--
-- Name: lifts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lifts ALTER COLUMN id SET DEFAULT nextval('public.lifts_id_seq'::regclass);


--
-- Name: skills id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skills ALTER COLUMN id SET DEFAULT nextval('public.skills_id_seq'::regclass);


--
-- Name: user_skills id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_skills ALTER COLUMN id SET DEFAULT nextval('public.user_skills_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
bbdb7c9ba9ee
\.


--
-- Data for Name: benchmark_results; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.benchmark_results (id, user_id, benchmark_id, time_seconds, rounds, reps, rx, date, notes, created_at) FROM stdin;
1	1	6	1200	\N	\N	t	2026-02-09	\N	2026-02-09 17:24:26.891155
\.


--
-- Data for Name: benchmarks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.benchmarks (id, name, description, benchmark_type, is_default) FROM stdin;
1	Fran	21-15-9 reps:\n- Thrusters (43/30 kg)\n- Pull-ups	for_time	t
2	Grace	30 reps:\n- Clean & Jerk (61/43 kg)	for_time	t
3	Isabel	30 reps:\n- Snatch (61/43 kg)	for_time	t
4	Diane	21-15-9 reps:\n- Deadlifts (102/70 kg)\n- Handstand Push-ups	for_time	t
5	Elizabeth	21-15-9 reps:\n- Cleans (61/43 kg)\n- Ring Dips	for_time	t
6	Amanda	9-7-5 reps:\n- Muscle-ups\n- Squat Snatch (61/43 kg)	for_time	t
7	Jackie	- 1000m Row\n- 50 Thrusters (20/15 kg)\n- 30 Pull-ups	for_time	t
8	Karen	- 150 Wall Balls (9/6 kg)	for_time	t
9	Murph	Con chaleco (9/6 kg):\n- 1.6 km Run\n- 100 Pull-ups\n- 200 Push-ups\n- 300 Air Squats\n- 1.6 km Run	for_time	t
10	DT	5 rounds (70/47 kg):\n- 12 Deadlifts\n- 9 Hang Power Cleans\n- 6 Push Jerks	for_time	t
11	Kalsu	- 100 Thrusters (61/43 kg)\n- EMOM 5 Burpees	for_time	t
12	Cindy	20 min AMRAP:\n- 5 Pull-ups\n- 10 Push-ups\n- 15 Air Squats	amrap	t
13	Mary	20 min AMRAP:\n- 5 Handstand Push-ups\n- 10 Pistols\n- 15 Pull-ups	amrap	t
14	Chelsea	30 min EMOM:\n- 5 Pull-ups\n- 10 Push-ups\n- 15 Air Squats	amrap	t
\.


--
-- Data for Name: exercises; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.exercises (id, name, is_default) FROM stdin;
1	Back Squat	t
2	Front Squat	t
3	Deadlift	t
4	Snatch	t
5	Clean & Jerk	t
6	Clean	t
7	Overhead Press	t
8	Bench Press	t
9	Thruster	t
10	Push Press	t
11	Power Clean	t
12	Power Snatch	t
\.


--
-- Data for Name: lifts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lifts (id, user_id, exercise_id, weight, reps_type, date, created_at) FROM stdin;
1	1	5	150	1	2026-02-09	2026-02-09 17:22:38.72237
\.


--
-- Data for Name: skills; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.skills (id, name, is_default) FROM stdin;
1	Pull-up	t
2	Chest-to-bar	t
3	Muscle-up (bar)	t
4	Muscle-up (ring)	t
5	Handstand Walk	t
6	Handstand Push-up	t
7	Pistol Squat	t
8	Double Under	t
9	Toes-to-bar	t
10	Rope Climb	t
11	L-sit	t
\.


--
-- Data for Name: user_skills; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_skills (id, user_id, skill_id, unlocked_date) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, email, password_hash, created_at, profile_photo, dark_mode) FROM stdin;
1	llibert	foo@bar.com	$2b$12$2q1KXfUbbK/HYW4TaUSp4eLXCXvMzXxCAWPO29gyZD/.LGZssLAlG	2026-02-09 17:09:14.394057	\N	t
\.


--
-- Name: benchmark_results_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.benchmark_results_id_seq', 1, true);


--
-- Name: benchmarks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.benchmarks_id_seq', 14, true);


--
-- Name: exercises_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.exercises_id_seq', 12, true);


--
-- Name: lifts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.lifts_id_seq', 1, true);


--
-- Name: skills_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.skills_id_seq', 11, true);


--
-- Name: user_skills_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_skills_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: benchmark_results benchmark_results_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.benchmark_results
    ADD CONSTRAINT benchmark_results_pkey PRIMARY KEY (id);


--
-- Name: benchmarks benchmarks_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.benchmarks
    ADD CONSTRAINT benchmarks_name_key UNIQUE (name);


--
-- Name: benchmarks benchmarks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.benchmarks
    ADD CONSTRAINT benchmarks_pkey PRIMARY KEY (id);


--
-- Name: exercises exercises_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exercises
    ADD CONSTRAINT exercises_name_key UNIQUE (name);


--
-- Name: exercises exercises_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exercises
    ADD CONSTRAINT exercises_pkey PRIMARY KEY (id);


--
-- Name: lifts lifts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lifts
    ADD CONSTRAINT lifts_pkey PRIMARY KEY (id);


--
-- Name: skills skills_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skills
    ADD CONSTRAINT skills_name_key UNIQUE (name);


--
-- Name: skills skills_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skills
    ADD CONSTRAINT skills_pkey PRIMARY KEY (id);


--
-- Name: user_skills uq_user_skill; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_skills
    ADD CONSTRAINT uq_user_skill UNIQUE (user_id, skill_id);


--
-- Name: user_skills user_skills_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_skills
    ADD CONSTRAINT user_skills_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: benchmark_results benchmark_results_benchmark_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.benchmark_results
    ADD CONSTRAINT benchmark_results_benchmark_id_fkey FOREIGN KEY (benchmark_id) REFERENCES public.benchmarks(id);


--
-- Name: benchmark_results benchmark_results_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.benchmark_results
    ADD CONSTRAINT benchmark_results_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: lifts lifts_exercise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lifts
    ADD CONSTRAINT lifts_exercise_id_fkey FOREIGN KEY (exercise_id) REFERENCES public.exercises(id);


--
-- Name: lifts lifts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lifts
    ADD CONSTRAINT lifts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_skills user_skills_skill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_skills
    ADD CONSTRAINT user_skills_skill_id_fkey FOREIGN KEY (skill_id) REFERENCES public.skills(id);


--
-- Name: user_skills user_skills_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_skills
    ADD CONSTRAINT user_skills_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict hI3ObjuejUevBicD1dMx02iKLDXlPQeLPcEiw7DhChVFQ0RykijL4jw4WvO47hA

